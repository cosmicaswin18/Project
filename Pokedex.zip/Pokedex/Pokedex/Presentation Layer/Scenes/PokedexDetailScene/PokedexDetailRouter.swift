//
//  PokedexDetailRouter.swift
//  Pokedex
//
//  Created by durgesh-10379 on 26/08/21.
//

import Foundation

protocol PokedexDetailRouter {
    
}

class PokedexDetailRouterImplementation: PokedexDetailRouter {
    
}
